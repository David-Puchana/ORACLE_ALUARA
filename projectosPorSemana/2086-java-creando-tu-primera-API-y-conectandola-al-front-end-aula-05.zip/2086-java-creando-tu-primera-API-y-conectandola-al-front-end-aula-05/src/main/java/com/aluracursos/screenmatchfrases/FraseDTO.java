package com.aluracursos.screenmatchfrases;

public record FraseDTO(
         String titulo,
         String frase,
         String personaje,
         String poster) {
}
