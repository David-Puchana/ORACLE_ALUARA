package com.aluracursos.screenmatchfrases;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScreenmatchFrasesApplicationTests {

	@Test
	void contextLoads() {
	}

}
