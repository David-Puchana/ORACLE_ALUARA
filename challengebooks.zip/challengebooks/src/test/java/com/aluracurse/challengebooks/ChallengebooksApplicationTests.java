package com.aluracurse.challengebooks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengebooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
