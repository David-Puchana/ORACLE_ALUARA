package com.aluracurse.challengebooks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChallengebooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChallengebooksApplication.class, args);
	}

}
